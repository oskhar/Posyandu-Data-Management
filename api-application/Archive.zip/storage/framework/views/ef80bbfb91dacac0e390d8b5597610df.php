<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e($data['title']); ?></title>
</head>
<body>
    <p><?php echo e($data['body']); ?></p>
    <a href="<?php echo e($data['url']); ?>">Ubah Password</a>
    <p>Terimakasih.</p>
</body>
</html><?php /**PATH /srv/http/myApp/OnDevelopment-SoftwareEngineering-StudentProject/api-application/resources/views/forget-password.blade.php ENDPATH**/ ?>