<!DOCTYPE html>
<html>
<head>
    <title>OpenAPI Documentation</title>
    <link rel="stylesheet" href="<?php echo e(asset('swagger-ui.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('logo.png')); ?>" type="image/x-icon">
</head>
<body>
    <div id="swagger-ui"></div>

    <script src="<?php echo e(asset('swagger-ui-bundle.js')); ?>"></script>
    <script>
        window.onload = function() {
            const ui = SwaggerUIBundle({
                url: "openapi-posyandu-melati.yml",
                dom_id: "#swagger-ui",
            });
        }
    </script>
</body>
</html>
<?php /**PATH /srv/http/myApp/OnDevelopment-SoftwareEngineering-StudentProject/api-application/resources/views/welcome.blade.php ENDPATH**/ ?>